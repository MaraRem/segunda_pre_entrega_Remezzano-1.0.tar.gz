from setuptools import setup
setup (
    name = "segunda_pre_entrega_Remezzano",
    version="1.0",
    description="Estoy intentado hacer un paquete distribuible",
    author="Mara Remezzano",
    author_email="mararemezzano@gmail.com",

    packages=["segunda_pre_entrega_remezzano"]
        
)